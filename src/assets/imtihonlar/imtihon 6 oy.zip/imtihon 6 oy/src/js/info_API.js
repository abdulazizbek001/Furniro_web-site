const elMovie = [
    {
        "ytid": 1,
        "image": "http://127.0.0.1:5500/src/assets/img/info_API-img1.jpg",
        "name": "Syltherine",
        "fullName": "Stylish cafe chair",
        "money": "Rp 2.500.000",
        "fakeMoney": "Rp 3.500.000",

    },
    {
        "ytid": 2,
        "image": "http://127.0.0.1:5500/src/assets/img/info_API-img1.jpg",
        "name": "Leviosa",
        "fullName": "Stylish cafe chair",
        "money": "Rp 2.500.000",
    },
    {
        "ytid": 3,
        "image": "http://127.0.0.1:5500/src/assets/img/info_API-img1.jpg",
        "name": "Lolito",
        "fullName": "Luxury big sofa",
        "money": "Rp 7.000.000",
        "fakeMoney": "Rp 14.000.000",
    },
    {
        "ytid": 4,
        "image": "http://127.0.0.1:5500/src/assets/img/info_API-img1.jpg",
        "name": "Respira",
        "fullName": "Outdoor bar table and stool",
        "money": "Rp 500.000",
        "fakeMoney": "Rp 14.000.000",
    },
    {
        "ytid": 5,
        "image": "http://127.0.0.1:5500/src/assets/img/info_API-img1.jpg",
        "name": "Grifo",
        "fullName": "Night lamp",
        "money": "Rp 1.500.000"
    },
    {
        "ytid": 6,
        "image": "http://127.0.0.1:5500/src/assets/img/info_API-img1.jpg",
        "name": "Muggo",
        "fullName": "Small mug",
        "money": "Rp 150.000",
    },
    {
        "ytid": 7,
        "image": "http://127.0.0.1:5500/src/assets/img/info_API-img1.jpg",
        "name": "Pingky",
        "fullName": "Cute bed set",
        "money": "Rp 7.000.000",
        "fakeMoney": "Rp 14.000.000",
    },

    {
        "ytid": 8,
        "image": "http://127.0.0.1:5500/src/assets/img/info_API-img1.jpg",
        "name": "Potty",
        "fullName": "Minimalist flower pot",
        "money": "Rp 500.000",
    },
]