// const elAnimatonList = document.querySelector('.animation_list');
// const elAnimationItem = document.querySelectorAll('.animation_item');

// function elData() {
//     elAnimatonList.style.cssText = `
//         position: relative;
//         right: 1000px;
//         transition: all 3s ease;
//     `;
// };
// elAnimatonList.append(elAnimationItem)
// setInterval(() => {
//     elData()
//     elAnimatonList.style.cssText = `
//         transition: all 3s ease;
// `;
// }, 2000);
//     setInterval(() => {
//         elAnimatonList.style.cssText = `
//         position: relative;
//         right: 1000px;
//         transition: all 3s ease;
//     `;
//     }, 3000);